package vendormangement;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vendor.connection.VendorConnection;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	/** Process the HTTP Get request */
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		Connection con=VendorConnection.get_connection();

		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		// get the variables entered in the form
		String name = req.getParameter("name");
		int userid = Integer.parseInt(req.getParameter("userid"));
		String password = req.getParameter("password");
		String Email = req.getParameter("Email");
		int phone = Integer.parseInt(req.getParameter("Phone"));
		String vname = req.getParameter("vname");
		String spocname = req.getParameter("spocname");
		int vphone = Integer.parseInt(req.getParameter("vPhone"));
		
			String sql = "insert into vendormanagement values (?,?,?,?,?,?,?,?)";
			
			PreparedStatement pst;
			try {
				pst = con.prepareStatement(sql);
				pst.setString(1, name);
				pst.setInt(2, userid);
				pst.setString(3, password);
				pst.setString(4, Email);
				pst.setInt(5, phone);
				pst.setString(6, vname);
				pst.setString(7, spocname);
				pst.setInt(8, vphone);
				pst.executeUpdate();
				res.sendRedirect("ui.html");
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
}
