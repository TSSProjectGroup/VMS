package upload;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.vendor.connection.VendorConnection;

/**
 * Servlet implementation class UploadFile
 */
@WebServlet("/UploadFile")
public class UploadFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   InputStream ip=null;
   Connection con=VendorConnection.get_connection();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id=Integer.parseInt(request.getParameter("id"));
		String s=request.getParameter("browse");
		System.out.println(s);
		//Part fil=request.getPart("browse");
		
		
		//System.out.println(fil);
		
			//ip=fil.getInputStream();
			//System.out.println(ip);
			try {
				PreparedStatement ps = con.prepareStatement("insert into imgtable values(?,?)");
				ps.setInt(1, id);
				FileInputStream fin = new FileInputStream(s);
				ps.setBinaryStream(2, fin, fin.available());
				ps.executeUpdate();
				PrintWriter pw=response.getWriter();
				pw.println("<h1>Resume Uploaded</h1>");
				RequestDispatcher rd;
			rd=	request.getRequestDispatcher("save.html");
				rd.include(request, response);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
	}


}
