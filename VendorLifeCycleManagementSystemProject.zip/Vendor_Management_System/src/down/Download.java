package down;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Download
 */
@WebServlet("/Download")
public class Download extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id=request.getParameter("id");
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "Rajasekar", "12345");

			PreparedStatement ps = con.prepareStatement("select * from imgtable where name=?");
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {// now on 1st row

				Blob b = rs.getBlob(2);// 2 means 2nd column data
				byte barr[] = b.getBytes(1, (int) b.length());// 1 means first
																// image

				FileOutputStream fout = new FileOutputStream("C:\\Users\\Training\\Desktop\\test\\in.doc");
				fout.write(barr);

				fout.close();
			} // end of if
			System.out.println("ok");
			
			

			con.close();
			PrintWriter pw=response.getWriter();
			pw.println("<html>");
			pw.println("<body background='1.jpg'>");
			pw.println("<center>");
			
			
			pw.println("<h1><font color='white'>C:\\Users\\Training\\Desktop\\test\\in.doc</font></h1><br/>");
			pw.println("<a href=download.html>CLICK HERE TO DOWNLOAD THE DOCUMENT</a><br/><br/>");
			
			
			pw.println("<a href='change.html'>Status change</a><br/>");
			pw.println("</center>");
			pw.println("<br/>");
			
			
			pw.println("</body>");
			pw.println("</html>");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
	

