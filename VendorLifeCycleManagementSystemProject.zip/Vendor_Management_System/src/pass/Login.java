package pass;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int uname=Integer.parseInt(request.getParameter("uname"));
		String cp=request.getParameter("curr");
		Dao d=new Dao();
		boolean status =d.check(uname,cp);
		RequestDispatcher rd;
		PrintWriter pw=response.getWriter();
	if(status)
	{pw.println("<html>");
	pw.println("<body>");
		pw.print("<form action='SelectAll' method='post'>");
		pw.print(	"<input type='submit' value='Submit'>"
				+ "</form>");
		
	}
	}


}
