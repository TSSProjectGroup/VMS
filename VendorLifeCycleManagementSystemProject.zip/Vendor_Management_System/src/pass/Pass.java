package pass;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Pass
 */
@WebServlet("/Pass")
public class Pass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int uname=Integer.parseInt(request.getParameter("uname"));
		String cp=request.getParameter("curr");
		String np=request.getParameter("np");
		String rp=request.getParameter("rp");
		Dao d=new Dao();
		boolean status =d.check(uname,cp);
		RequestDispatcher rd;
		PrintWriter pw=response.getWriter();
		
		if(status)
		{
			if(np.equals(rp)){
		
				d.change(np);
				
				
			rd=request.getRequestDispatcher("ui.html");
			rd.include(request, response);
				
			}
		}
	
		
		
	}

	
}
