package pass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Dao {
	
	
	 boolean check(int uname, String cp) {
		 boolean st=false;
		 try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE:","Rajasekar","12345");
			PreparedStatement  ps=con.prepareStatement("select password from vendormanagement where userid=?");
			ps.setInt(1, uname);
			ResultSet rs=ps.executeQuery();
			 st=rs.next();
			
			} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return st;
		 
		 
	}

	public int change(String np) {
		// TODO Auto-generated method stub
		int st=0;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE:","varsha","varsha");
		PreparedStatement  ps=con.prepareStatement("update abc set pass=? where pass=pass");
		ps.setString(1, np);
		st=ps.executeUpdate();
		
		
		} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return st;
	}
	 
	 
	

}
