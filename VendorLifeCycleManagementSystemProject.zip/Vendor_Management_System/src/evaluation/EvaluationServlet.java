package evaluation;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vendor.connection.VendorConnection;
import com.vendor.dao.VendorDao;
import com.vendor.pojo.VendorPojo;

/**
 * Servlet implementation class EvaluationServlet
 */
@WebServlet("/EvaluationServlet")
public class EvaluationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EvaluationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	try
	{	Connection con=VendorConnection.get_connection();
		PrintWriter pw = response.getWriter();
		ResultSet rs;
		PreparedStatement ps;
		Statement st;
			st=con.createStatement();
			rs=st.executeQuery("select * from req");	
		pw.println("<html><body>");
		pw.println("<table border=1>");
		pw.println(
				"<tr><th>PLACE</th><th>Number Of Vacancies</th><th>Stream</th></tr>");
			while (rs.next()) {
				pw.println("<tr><td>" + rs.getString(1) + "</td><td>" + rs.getString(2) + "</td><td>" + rs.getString(3)+"</td></tr>");
			}
			pw.println("</table>");
			pw.println("<a href='List.html'>List</a><br/>");
			pw.println("<br/>");
			pw.println("<a href='ER.html'>Evaluate resume</a>");
			pw.println("</body></html>");
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	

}
