package change;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vendor.dao.VendorDao;
import com.vendor.pojo.VendorPojo;

/**
 * Servlet implementation class ChangeStatus
 */
@WebServlet("/ChangeStatus")
public class ChangeStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		String status=request.getParameter("status");
		VendorPojo pj=new VendorPojo();
		pj.setId(id);
		pj.setStatus(status);
		VendorDao dao=new VendorDao();
		dao.change(pj);
		PrintWriter pw=response.getWriter();
		pw.println("<a href='evaluation.html'></a><br/>");
		
		pw.println("<h1>Status changed</h1>");
		RequestDispatcher rd;
	rd=	request.getRequestDispatcher("ER.html");
		rd.include(request, response);
	}


}
