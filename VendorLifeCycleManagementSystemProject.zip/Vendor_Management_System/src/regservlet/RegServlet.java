package regservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vendor.connection.VendorConnection;
import com.vendor.pojo.VendorPojo;


@WebServlet("/RegServlet")
public class RegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		Connection con=VendorConnection.get_connection();
		PrintWriter pw=response.getWriter();
		String place=request.getParameter("place");
		String nov=request.getParameter("nov");
		String stream=request.getParameter("stream");
		ResultSet rs;
		PreparedStatement ps;
		Statement st;
			try {
				ps=con.prepareStatement("insert into req values(?,?,?)");
				 ps.setString(1, place);
				 ps.setString(2, nov);
				 ps.setString(3, stream);
				
				 ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<br/>");
		pw.println("PLACE DETAIL IS :"+place);
		pw.println("<br/>");
		pw.println("NUMBER OF VACANCY IS :"+nov);
		pw.println("<br/>");
		pw.println("STREAM IS :"+stream);
		pw.println("<br/>");
		pw.println("<a href='List.html'>List</a><br/>");
		pw.println("<br/>");
		pw.println("<a href='ER.html'>Evaluate resume</a>");
		pw.println("</html>");
		pw.println("</body>");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
